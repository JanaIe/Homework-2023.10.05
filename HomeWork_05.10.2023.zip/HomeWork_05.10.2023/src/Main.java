import com.sun.tools.attach.AgentInitializationException;

import java.util.Random;

public class Main {

    // 1 Напишите программу, в которой объявите переменные всех примитивных типов.
    // Значение для каждой переменной сгенерируйте с помощью класса Random.
    // При необходимости используйте приведение типов.
    // Полученные значения выведите в консоль.
    //2 В этой же программе создайте переменную типа String.
    //Сгенерируйте значение для строки. При необходимости используйте метод String.valueOf().
    // Ограничений на длину строки и содержимое нет. Полученное значение выведите в консоль.

    public static void main(String[] args) {

        Random rnd = new Random();

        int Age = rnd.nextInt(0,121);
        byte number = (byte) rnd.nextInt();
        double temp = rnd.nextDouble(0.5,1.0);
        long kg = rnd.nextLong(1,250);
        char km = (char) rnd.nextInt('A', 'Z');
        boolean past = rnd.nextBoolean();
        short typee = (short) rnd.nextInt() ;
        float tk = rnd.nextFloat(1.5F,2.2F);

        System.out.println(Age);
        System.out.println(number);
        System.out.println(temp);
        System.out.println(kg);
        System.out.println(km);
        System.out.println(past);
        System.out.println(typee);
        System.out.println(tk);

        String str = String.valueOf((char) rnd.nextInt('A', 'Z'))
                +(char) rnd.nextInt('A', 'Z')
                +(char) rnd.nextInt('A', 'Z')
                +(char) rnd.nextInt('A', 'Z');

        System.out.println(str);


    }
}