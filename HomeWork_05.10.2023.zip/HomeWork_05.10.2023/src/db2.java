import java.util.Scanner;

public class db2 {
    public static void main(String[] args) {


        System.out.println("write your name");
        System.out.println("write your Age");
        System.out.println("write your kg");
        Scanner scn = new Scanner(System.in);
        String Name = scn.next();
        Byte Age = scn.nextByte();
        Short kg = scn.nextShort();

        System.out.println("Уважаемый, " + Name+ "! В свои " +Age+ " лет Вы для нас дороги, как " + kg +
                " килограмм золота.");
    }
}
