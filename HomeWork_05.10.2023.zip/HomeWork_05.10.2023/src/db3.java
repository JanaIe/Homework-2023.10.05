import java.util.Scanner;

public class db3 {
    public static void main(String[] args) {
        //Напишите программу, которая получает от пользователя два целых числа и затем
        // вычисляет сумму (сложение), разницу (вычитание),
        // произведение (умножение) и частное (деление) введённых чисел.
        // Результат вычислений выведите в консоль.


        System.out.println("write your age");
        System.out.println("write your kg ");
        Scanner scn = new Scanner(System.in);
        int age = scn.nextInt();
        byte kg = scn.nextByte();


        System.out.println(age+kg);
        System.out.println(age-kg);
        System.out.println(age/kg);
        System.out.println(age*kg);


    }
}
